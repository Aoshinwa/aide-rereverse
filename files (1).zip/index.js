/**
 * RE:REVERSE — Cloud Function "analyzeCandidature"
 * ==================================================
 * Pourquoi cette fonction existe :
 * Le navigateur ne doit JAMAIS appeler l'API Gemini directement avec une
 * vraie clé API — cette clé serait visible dans le code source de la page
 * et n'importe qui pourrait la copier et l'utiliser à vos frais.
 * Cette Cloud Function reçoit la demande du site, y ajoute la clé secrète
 * (stockée côté serveur, jamais envoyée au navigateur), interroge l'API
 * Gemini (Google AI), puis renvoie uniquement le résultat déjà validé.
 *
 * Migration Anthropic -> Gemini :
 * L'interface côté client ne change pas : le front-end continue d'appeler
 * analyzeCandidature({ systemPrompt, userMessage }) exactement comme avant.
 * Toute la logique d'analyse (priorité à l'Objectif RP, détection des
 * objectifs démesurés, calibrage sur les fiches de référence, format du
 * verdict) reste définie dans systemPrompt côté re-reverse.html — cette
 * fonction reste un simple proxy sécurisé, seul le modèle change.
 *
 * Déploiement :
 *   1) cd functions && npm install
 *   2) firebase functions:secrets:set GEMINI_API_KEY
 *      (colle ta clé API Gemini — gratuite sur https://aistudio.google.com/apikey)
 *   3) firebase deploy --only functions
 *
 * Le front-end (re-reverse.html) appelle déjà cette fonction via
 * httpsCallable(functions, "analyzeCandidature") — aucune autre
 * configuration n'est nécessaire côté client.
 *
 * À noter : le modèle gemini-2.5-flash est annoncé par Google comme
 * devant s'arrêter le 16 octobre 2026. Si cette fonction est encore en
 * service après cette date, change simplement la constante GEMINI_MODEL
 * ci-dessous (par ex. vers un modèle Gemini 3.x plus récent) — aucune
 * autre modification n'est nécessaire.
 */

const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { defineSecret } = require("firebase-functions/params");
const {
  GoogleGenerativeAI, SchemaType, HarmCategory, HarmBlockThreshold
} = require("@google/generative-ai");

const GEMINI_API_KEY = defineSecret("GEMINI_API_KEY");
const GEMINI_MODEL = "gemini-2.5-flash";

// Schéma strict envoyé à Gemini pour forcer une sortie JSON valide et
// conforme, sans dépendre uniquement des instructions du prompt (ce qui
// évite la plupart des erreurs de parsing côté client).
const RESULT_SCHEMA = {
  type: SchemaType.OBJECT,
  properties: {
    score: { type: SchemaType.INTEGER },
    decision: {
      type: SchemaType.STRING,
      enum: ["Très favorable", "Favorable", "À retravailler", "Défavorable"]
    },
    subScores: {
      type: SchemaType.OBJECT,
      properties: {
        coherence: { type: SchemaType.INTEGER },
        objectifRP: { type: SchemaType.INTEGER },
        equilibre: { type: SchemaType.INTEGER }
      },
      required: ["coherence", "objectifRP", "equilibre"]
    },
    problems: { type: SchemaType.ARRAY, items: { type: SchemaType.STRING } },
    objectifFeedback: { type: SchemaType.STRING },
    analysis: { type: SchemaType.STRING },
    improvements: { type: SchemaType.ARRAY, items: { type: SchemaType.STRING } }
  },
  required: [
    "score", "decision", "subScores", "problems",
    "objectifFeedback", "analysis", "improvements"
  ]
};

// One Piece RP implique des thèmes de conflit/violence fictionnelle "normaux"
// pour le genre : on assouplit les filtres de sécurité pour éviter des
// blocages abusifs, sans les désactiver complètement.
const SAFETY_SETTINGS = [
  { category: HarmCategory.HARM_CATEGORY_HARASSMENT, threshold: HarmBlockThreshold.BLOCK_ONLY_HIGH },
  { category: HarmCategory.HARM_CATEGORY_HATE_SPEECH, threshold: HarmBlockThreshold.BLOCK_ONLY_HIGH },
  { category: HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT, threshold: HarmBlockThreshold.BLOCK_ONLY_HIGH },
  { category: HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT, threshold: HarmBlockThreshold.BLOCK_ONLY_HIGH }
];

exports.analyzeCandidature = onCall(
  { secrets: [GEMINI_API_KEY], cors: true, timeoutSeconds: 60 },
  async (request) => {
    // Seuls les visiteurs passés par Firebase Auth (même anonyme, mis en
    // place côté front) peuvent appeler cette fonction. Ça évite qu'un
    // script tiers l'appelle directement en boucle et fasse exploser la
    // facture Gemini.
    if (!request.auth) {
      throw new HttpsError("unauthenticated", "Connexion requise.");
    }

    const { systemPrompt, userMessage } = request.data || {};
    if (typeof systemPrompt !== "string" || typeof userMessage !== "string" ||
        !systemPrompt.trim() || !userMessage.trim()) {
      throw new HttpsError("invalid-argument", "Requête malformée.");
    }
    // Garde-fou supplémentaire côté serveur, indépendant de la limite déjà
    // vérifiée dans le navigateur (qui peut toujours être contournée).
    if (userMessage.length > 12000 || systemPrompt.length > 20000) {
      throw new HttpsError("invalid-argument", "Candidature trop longue.");
    }

    const genAI = new GoogleGenerativeAI(GEMINI_API_KEY.value());
    const model = genAI.getGenerativeModel({
      model: GEMINI_MODEL,
      systemInstruction: systemPrompt,
      safetySettings: SAFETY_SETTINGS,
      generationConfig: {
        temperature: 0.4,
        maxOutputTokens: 2048,
        responseMimeType: "application/json",
        responseSchema: RESULT_SCHEMA
      }
    });

    let generation;
    try {
      generation = await model.generateContent(userMessage);
    } catch (err) {
      console.error("Appel réseau vers l'API Gemini impossible :", err);
      const msg = String((err && err.message) || "");
      if (msg.includes("429") || /quota/i.test(msg)) {
        throw new HttpsError("resource-exhausted", "Trop de lectures en cours.");
      }
      if (msg.includes("401") || msg.includes("403") || /API key/i.test(msg)) {
        throw new HttpsError("internal", "Erreur de configuration du service de lecture.");
      }
      throw new HttpsError("unavailable", "Service de lecture temporairement injoignable.");
    }

    const result = generation && generation.response;

    // Une candidature bloquée par les filtres de sécurité Gemini avant même
    // la génération n'a aucun candidat : il faut le détecter explicitement,
    // sinon le code plus bas planterait sur une erreur peu claire.
    const blockReason = result && result.promptFeedback && result.promptFeedback.blockReason;
    if (blockReason) {
      console.error("Candidature bloquée par les filtres de sécurité Gemini :", blockReason);
      throw new HttpsError(
        "failed-precondition",
        "Cette candidature contient des éléments signalés par les filtres de sécurité et n'a pas pu être analysée."
      );
    }

    const candidate = result && result.candidates && result.candidates[0];
    const finishReason = candidate && candidate.finishReason;
    if (finishReason && finishReason !== "STOP") {
      console.error("Réponse Gemini incomplète, finishReason :", finishReason);
      throw new HttpsError(
        "internal",
        "Le service de lecture n'a pas pu terminer son analyse (réponse tronquée ou signalée). Réessaie dans un instant."
      );
    }

    let text;
    try {
      text = result.text();
    } catch (err) {
      console.error("Impossible d'extraire le texte de la réponse Gemini :", err);
      throw new HttpsError("internal", "Réponse du service de lecture illisible.");
    }

    if (!text || !text.trim()) {
      throw new HttpsError("internal", "Le service de lecture n'a renvoyé aucun texte exploitable.");
    }

    let parsed;
    try {
      parsed = JSON.parse(text);
    } catch (err) {
      console.error("JSON renvoyé par Gemini invalide :", text.slice(0, 500));
      throw new HttpsError("internal", "La réponse du service de lecture n'a pas pu être interprétée. Réessaie dans un instant.");
    }

    // Le front-end (re-reverse.html) attend { result: {...} } et applique
    // ensuite sa propre normalisation/bornage des champs (normalizeAIResult).
    return { result: parsed };
  }
);
